# GigaLoterías Android — prototipo 0.1

Este proyecto NO copia el código propietario del ejecutable GigaLOTERÍAS.
Reimplementa de forma independiente una primera capa estadística usando los
historiales suministrados por el usuario.

## Incluido
- Historial Tinka (Perú) extraído del ZIP proporcionado.
- Carga de archivos CSV desde el celular.
- Frecuencia de aparición.
- Repetición respecto al último sorteo.
- Balance pares/impares.
- Conteo de consecutivos.
- Generador de 20 combinaciones con puntuación heurística.
- Arquitectura preparada para añadir Kábala y otros juegos.

Formato CSV:
fecha,n1,n2,n3,n4,n5,n6

## Importante
Los algoritmos internos exactos de GigaLOTERÍAS 15.26 no están incluidos en
el ejecutable como código fuente legible. Este proyecto es una implementación
independiente y no afirma reproducir exactamente sus fórmulas.

## Compilar
Abrir esta carpeta con Android Studio y ejecutar:
Build > Build APK(s)

Requiere Android Studio con SDK 35 y conexión para descargar Gradle/Android
Gradle Plugin si no están instalados localmente.
